# Image inventory

## Original uploaded hardware/document photos (43)

- `IMG_01AC6E45-A25A-4655-83B9-49AAD5665E45.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_0F817CAD-5550-4FB8-8F43-C0823706B818.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_172DD977-287F-4D60-B968-F201E1B96575.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4294.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4295.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4296.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4297.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4298.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4299.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4300.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4301.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4302.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4303.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4304.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4305.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4306.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4307.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4308.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4309.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4310.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4311.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4312.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4313.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4320.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_4CA13A3C-6E46-47E3-A8E8-9F04FD1DA576.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_67FABB23-8554-4C62-AF15-7F8549B9B791.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_6BEFE09D-66E5-472F-B693-2A4F64391955.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_74608155-356D-4673-A7F0-686889B0E4D6.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_7813230F-EA70-4DBD-BBC5-973C1287D37B.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_80FAF62A-1F47-49ED-9D08-F04BCB01142A.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_98A42CE2-1E93-4D20-9DC9-4B26A8864AA6.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_A720CAC8-ED09-4BE5-9F3F-33FDD53C6B76.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_C16523C4-2DFA-48C0-8AC1-152ACA79FF6E.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_C80468FF-D6C3-43D5-9786-736ECCB84266.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_CABB0C9D-69AD-4D47-BB88-B1FA12D58280.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_CBB27688-1E3E-424A-8981-4B6701A246B5.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_D389F7C2-90DD-4B74-9269-1BC7FB4E8593.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_E110F02F-B442-4EE5-AC9E-6804BCC5E2FF.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_E3030438-0104-47DF-8BE8-8AED24E1DEFB.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_E43C42FF-6CF0-4207-BCFD-67A0740607CE.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_E9D02FBC-43BF-4EE2-88FF-CD5C50A5C022.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_F9BC24A3-94EB-45A1-B910-E96F63EF6F78.jpeg` — original uploaded image; capture date not confirmed.
- `IMG_FCF98993-7B21-4DDD-B369-3C554828368C.jpeg` — original uploaded image; capture date not confirmed.

## Engineering artwork (9)

- `Conceptual electric bike wiring diagram.png` — generated/conceptual engineering artwork or annotated diagram.
- `Electric bike wiring schematic design.png` — generated/conceptual engineering artwork or annotated diagram.
- `E-scooter display control module guide.png` — generated/conceptual engineering artwork or annotated diagram.
- `Display Control Module Teardown Guide.png` — generated/conceptual engineering artwork or annotated diagram.
- `ESP32 Smart E-Bike Dashboard Blueprint.png` — generated/conceptual engineering artwork or annotated diagram.
- `ESP32 Dashboard Replacement Wiring Guide.png` — generated/conceptual engineering artwork or annotated diagram.
- `ESP32 PCB Engineering Assembly Infographic.png` — generated/conceptual engineering artwork or annotated diagram.
- `Electric Scooter Controller Exploded CAD Infographic.png` — generated/conceptual engineering artwork or annotated diagram.
- `Display Control Module PCB Trace Map.png` — generated/conceptual engineering artwork or annotated diagram.

## Date policy
Dates are left blank where original capture dates are not confirmed. Library upload timestamps are not necessarily capture dates.

## Evidence distinction
Original photographs are evidence. Generated diagrams and 3D renders are design aids only and are not manufacturer schematics, measured dimensions, or verified connector pinouts.
