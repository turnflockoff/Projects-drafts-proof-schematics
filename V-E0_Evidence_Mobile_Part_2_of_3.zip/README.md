# V-E0 / OEV rideshare scooter-e-bike research archive

This package consolidates the recovered project photos and engineering illustrations. Original photographs are kept separate from generated/conceptual engineering artwork. No source image has been overwritten.

## Contents
- `01_original_hardware_photos/` — 43 unique original photo/document images recovered from the related project archive.
- `02_generated_engineering_artwork/` — 9 engineering diagrams, PCB concept illustrations, teardown guides, and trace-map artwork.
- `IMAGE_INVENTORY.md` — file-by-file list.

## Evidence summary
The recovered source set includes close-up photographs of the V-E0 display/control enclosure, nine-port connector block, original green PCBs, LTE/GPS-related board components, test-pad areas, and a battery label photograph. Additional photos include module/board details and document/receipt-like images. The generated artwork includes conceptual wiring diagrams, display-module teardown views, ESP32 dashboard/PCB concepts, and an illustrated PCB trace map.

## Hypothesis / reasoning
The original scooter electronics appear to have a separable display/control/communications assembly. A custom ESP32-based dashboard or interface board may be feasible, but only after connector pin functions, electrical levels, power requirements, communication protocol, and mechanical dimensions are verified.

## What was done
- Collected and organized original photos of the scooter electronics and related documentation.
- Separated original evidence from generated engineering artwork.
- Grouped the artwork around wiring architecture, display/control teardown, PCB trace interpretation, and ESP32 replacement concepts.

## What happened
The archive documents a meaningful hardware-inspection and design-concept effort. It does not by itself prove a completed reverse-engineering result, verified pinout, decoded communications protocol, fabricated replacement PCB, or successful vehicle test. Treat all generated pinouts, component identifications, dimensions, and wiring as conceptual unless corroborated by measurements.

## What I would change next
1. Photograph each board side square-on with a scale and retain original metadata.
2. Record connector orientation, pin numbers, wire colors, measured voltages, and continuity in a test log.
3. Identify ICs from readable markings and datasheets.
4. Capture serial/CAN traffic passively with appropriate electrical isolation.
5. Create a measured KiCad schematic and bench prototype before any vehicle integration.
6. Keep propulsion, throttle, braking, rental access, payment, geofence, and fleet-management controls untouched.

## Dates
Dates are intentionally left blank in the image inventory unless reliably supported by source metadata. File-library upload timestamps are not necessarily capture dates.
